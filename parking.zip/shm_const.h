
#define CLE_SHM           0x555
#define CLE_SEM           0x111
#define SHM_SIZE          sizeof(int)

/*
#define MAX               500
#define DELAI             5
#define VARIATION         3
#define DELAI_FILS        2
#define DELAI_TENTATIVE   2
#define MAX_TENTATIVE     10
*/
